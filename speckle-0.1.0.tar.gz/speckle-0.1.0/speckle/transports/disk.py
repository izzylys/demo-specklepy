import os
from speckle.transports.abstract_transport import AbstractTransport


class DiskTransport(AbstractTransport):
    _name = "Disk"
    __root_path: str = None
    saved_obj_count: int = 0

    def __init__(self, base_path: str = None) -> None:
        if base_path == None:
            self.__root_path = os.path.join(
                os.getenv("APPDATA"), "Speckle", "DiskTransportFiles"
            )
        else:
            self.__root_path = base_path
        os.makedirs(self.__root_path, exist_ok=True)

    def begin_write(self):
        self.saved_obj_count = 0

    def save_object(self, id: str, serialized_object: str or AbstractTransport) -> None:
        raise NotImplementedError

    def save_object_from_transport(
        self, id: str, source_transport: AbstractTransport
    ) -> None:
        raise NotImplementedError

    def get_object(self, id: str) -> str:
        raise NotImplementedError
