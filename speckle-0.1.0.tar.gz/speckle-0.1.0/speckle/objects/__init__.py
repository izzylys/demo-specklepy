"""Builtin Speckle object kit."""

from speckle.objects.base import Base

__all__ = ["Base"]
