from __future__ import annotations

from typing import List, Optional

from .base import Base


class SpeckleLine(Base):
    value: List[float] = None

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)


class SpeckleBeam(Base):
    _base_line: SpeckleLine = None

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._base_line = None

    @property
    def base_line(self):
        print("getting base_line")
        return self._base_line

    @base_line.setter
    def base_line(self, value: SpeckleLine):
        print("setting base_line")
        self._base_line = value
