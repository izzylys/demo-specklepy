# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['speckle',
 'speckle.api',
 'speckle.api.resources',
 'speckle.logging',
 'speckle.objects',
 'speckle.serialization',
 'speckle.transports']

package_data = \
{'': ['*']}

install_requires = \
['aiohttp>=3.7.3,<4.0.0',
 'appdirs>=1.4.4,<2.0.0',
 'gql>=3.0.0a5,<4.0.0',
 'pydantic>=1.7.3,<2.0.0',
 'requests>=2.25.1,<3.0.0',
 'websockets>=8.1,<9.0']

setup_kwargs = {
    'name': 'speckle',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Izzy Lyseggen',
    'author_email': 'izzy.lyseggen@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.6.5,<4.0.0',
}


setup(**setup_kwargs)
